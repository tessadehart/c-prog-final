#include "player.hpp"

Player::Player(std::string name, int points)
{
    this->name = name;
    this->points = points;
}

